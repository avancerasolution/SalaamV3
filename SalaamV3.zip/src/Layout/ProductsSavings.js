import React, { Fragment } from 'react'
import ProductBanner from '../Components/ProductsSavings/ProductBanner'


function ProductsSavings() {
  return (
  
    <Fragment>

    
        <div className='container-fluid faderight '>
          <div className='row'>
            <ProductBanner/>
          </div>
          </div>
      
    </Fragment>

  )
}

export default ProductsSavings