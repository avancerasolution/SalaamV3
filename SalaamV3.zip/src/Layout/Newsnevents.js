import React from 'react'
import { Fragment } from 'react'
import NewsBanner from '../Components/News/NewsBanner'

function Newsnevents() {
  return (
    <Fragment>

    
    <div className='container-fluid faderight '>
      <div className='row'>
          <NewsBanner/>
      </div>
      </div>
  
</Fragment>
  )
}

export default Newsnevents