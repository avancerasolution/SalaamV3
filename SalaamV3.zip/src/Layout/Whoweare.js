import React, { Fragment } from 'react'
import Whobanner from '../Components/Whoweare/Whobanner';


function Whoweare() {
  return (

    <Fragment>


      <div className='container-fluid faderight'>
        <div className='row'>
          <Whobanner />
        </div>

      </div>


    </Fragment>

  )
}

export default Whoweare