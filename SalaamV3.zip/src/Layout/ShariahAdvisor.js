import React, { Fragment } from 'react'
import Companybanner from '../Components/Companyprofile/Companybanner'
import Shariahbanner from '../Components/Shariah/Shariahbanner'


function ShariahAdvisor() {
  return (
  
    <Fragment>

    
        <div className='container-fluid faderight'>
          <div className='row'>
              <Shariahbanner/> 
          </div>

          </div>
      
    </Fragment>

  )
}

export default ShariahAdvisor